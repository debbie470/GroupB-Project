﻿namespace MockExams.Models
{
    public class Staff
    {
       
            public int StaffId { get; set; }

            // Staff details
            public string JobRole { get; set; }
            public bool IsActive { get; set; }

          

    }
}
